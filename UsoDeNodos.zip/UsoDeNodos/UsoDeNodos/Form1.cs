namespace UsoDeNodos
{
    public partial class Form1 : Form
    {
        private Lista enlazada = new Lista();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Agrega dato
            int numero = Convert.ToInt32(textBox1.Text);
            enlazada.Insertar(numero);
            textBox1.Clear();
            actualizarLista();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Eliminar dato
            int numero = Convert.ToInt32(textBox1.Text);
            bool resultado = enlazada.Eliminar(numero);

            if (resultado) { //Preguntamos si es true
                actualizarLista();
                textBox1.Clear();
            }
            else
            {
                MessageBox.Show("No existia el numero, no se borro nada");
            }
        }

        private void actualizarLista()
        {
            listBox1.Items.Clear();
            listBox1.Items.AddRange(enlazada.obtenerLista());
        }
    }
}
