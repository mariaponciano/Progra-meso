﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsoDeNodos
{
    public class Nodo
    {
        public int numero;
        public Nodo siguiente;

        public Nodo(int numero) {
            this.numero = numero;
            siguiente = null;
        }
    }
}
