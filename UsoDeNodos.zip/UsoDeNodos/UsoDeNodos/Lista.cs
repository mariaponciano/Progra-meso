﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsoDeNodos
{
    public class Lista
    {
        private Nodo ultimo;

        public Lista()
        {
            ultimo = null;
        }

        //Insertar
        public void Insertar(int numero) {
            Nodo nuevo = new Nodo(numero);
            nuevo.siguiente = ultimo;
            ultimo = nuevo;
        }

        //Eliminar un nodo
        public bool Eliminar(int numero)
        {
            Nodo actual = ultimo, anterior = null;

            //Recorrer la lista de nodos para saber cual eliminar
            while (actual != null && actual.numero != numero)
            {
                anterior = actual;
                actual = actual.siguiente;
            }

            //Evaluar si el nodo que queriamos eliminar existia
            if (actual == null)
            { 
                //No se elimino nada porque no hay nada, duuuuh
                return false;
            }

            //Si si lo llegamos a encontrar
            if (anterior == null)
            {
                ultimo = actual.siguiente;
            }
            else
            {
                anterior.siguiente = actual.siguiente;
            }

            return true;
        }


        //Obtener la lista de strings para listar en listbox
        public string[] obtenerLista()
        {
            Nodo actual = ultimo;
            List<string> listado = new List<string>();

            while (actual != null)
            {
                string numeroActual = actual.numero.ToString();
                string numeroSiguiente = "ninguno";
                if (actual.siguiente != null)
                {
                    numeroSiguiente = actual.siguiente.numero.ToString();
                }
                
                listado.Add("Actual: " + numeroActual + " Siguiente: " + numeroSiguiente);
                actual = actual.siguiente;
            }

            return listado.ToArray();
        }
    }
}
